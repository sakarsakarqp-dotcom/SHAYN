CREATE TABLE IF NOT EXISTS users (
 id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','moderator','admin')),
 verified BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS listings (
 id BIGSERIAL PRIMARY KEY, owner_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
 type TEXT NOT NULL CHECK (type IN ('job','project','service','market')),
 title TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'عام',
 location TEXT DEFAULT 'عن بعد', price NUMERIC(12,2), currency TEXT DEFAULT 'USD',
 status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('draft','published','closed','hidden')),
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS applications (
 id BIGSERIAL PRIMARY KEY, listing_id BIGINT NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, message TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','rejected')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), UNIQUE(listing_id,user_id)
);
CREATE TABLE IF NOT EXISTS reviews (
 id BIGSERIAL PRIMARY KEY, reviewer_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 target_user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5), comment TEXT DEFAULT '',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), CHECK (reviewer_id <> target_user_id)
);
CREATE TABLE IF NOT EXISTS reports (
 id BIGSERIAL PRIMARY KEY, reporter_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
 listing_id BIGINT REFERENCES listings(id) ON DELETE CASCADE, reason TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','reviewing','resolved','dismissed')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS messages (
 id BIGSERIAL PRIMARY KEY, sender_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 recipient_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 body TEXT NOT NULL, read_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS listings_type_status_idx ON listings(type,status,created_at DESC);
CREATE INDEX IF NOT EXISTS messages_recipient_idx ON messages(recipient_id,created_at DESC);
