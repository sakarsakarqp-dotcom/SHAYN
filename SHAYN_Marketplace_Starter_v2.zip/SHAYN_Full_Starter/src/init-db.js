require('dotenv').config();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const db = require('./db');
(async()=>{
 try {
  await db.query(fs.readFileSync(path.join(__dirname,'../db/schema.sql'),'utf8'));
  const name=process.env.ADMIN_NAME||'أمير السوري'; const email=process.env.ADMIN_EMAIL||'Alswrya255@gmail.com';
  const password=process.env.ADMIN_PASSWORD;
  if (!password || password==='SET_A_STRONG_PASSWORD_BEFORE_FIRST_RUN') {
   console.log('Database schema created. Set ADMIN_PASSWORD in .env, then run npm run db:init again to create the admin account.');
  } else {
   const hash=await bcrypt.hash(password,12);
   await db.query(`INSERT INTO users(name,email,password_hash,role,verified) VALUES($1,$2,$3,'admin',true) ON CONFLICT(email) DO UPDATE SET name=EXCLUDED.name, role='admin', verified=true`,[name,email,hash]);
   console.log('Database ready and admin account ensured for:',email);
  }
 } catch(e){console.error(e.message);process.exitCode=1;} finally{await db.pool.end();}
})();
